#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav2_msgs.action import NavigateToPose
from rclpy.action import ActionClient
import math
import time

class MappingController(Node):
    def __init__(self):
        super().__init__('mapping_controller')
        
        # Action client for navigation
        self.nav_to_pose_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        
        # Manual control publisher
        self.cmd_vel_pub = self.create_publisher(Twist, 'cmd_vel', 10)
        
        # Mapping waypoints
        self.waypoints = [
            (2.0, 0.0, 0.0),    # Move forward 2m
            (2.0, 2.0, 1.57),   # Move right and turn
            (0.0, 2.0, 3.14),   # Move back
            (0.0, 0.0, 0.0)     # Return to start
        ]
        
        self.current_waypoint = 0
        self.mapping_complete = False
        
        self.get_logger().info('Mapping Controller started')
        
        # Start mapping after a delay
        self.create_timer(5.0, self.start_mapping)
    
    def start_mapping(self):
        self.get_logger().info('Starting autonomous mapping...')
        self.navigate_to_waypoint()
    
    def navigate_to_waypoint(self):
        if self.current_waypoint >= len(self.waypoints):
            self.get_logger().info('Mapping complete!')
            self.mapping_complete = True
            return
        
        x, y, theta = self.waypoints[self.current_waypoint]
        
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose.header.frame_id = 'map'
        goal_msg.pose.header.stamp = self.get_clock().now().to_msg()
        goal_msg.pose.pose.position.x = x
        goal_msg.pose.pose.position.y = y
        
        # Convert theta to quaternion
        from geometry_msgs.msg import Quaternion
        goal_msg.pose.pose.orientation = Quaternion(
            x=0.0,
            y=0.0,
            z=math.sin(theta/2.0),
            w=math.cos(theta/2.0)
        )
        
        self.nav_to_pose_client.wait_for_server()
        self.send_goal_future = self.nav_to_pose_client.send_goal_async(
            goal_msg,
            feedback_callback=self.feedback_callback
        )
        self.send_goal_future.add_done_callback(self.goal_response_callback)
    
    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().info('Goal rejected')
            return
        
        self.get_logger().info(f'Navigating to waypoint {self.current_waypoint + 1}')
        
        self.get_result_future = goal_handle.get_result_async()
        self.get_result_future.add_done_callback(self.get_result_callback)
    
    def get_result_callback(self, future):
        result = future.result().result
        self.get_logger().info(f'Reached waypoint {self.current_waypoint + 1}')
        self.current_waypoint += 1
        self.navigate_to_waypoint()
    
    def feedback_callback(self, feedback_msg):
        feedback = feedback_msg.feedback
        self.get_logger().info(f'Distance remaining: {feedback.distance_remaining:.2f}m')

def main(args=None):
    rclpy.init(args=args)
    mapping_controller = MappingController()
    rclpy.spin(mapping_controller)
    mapping_controller.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
