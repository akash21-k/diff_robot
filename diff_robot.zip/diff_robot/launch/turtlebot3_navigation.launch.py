import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, ExecuteProcess, RegisterEventHandler
from launch.event_handlers import OnProcessExit
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch_ros.actions import Node
from launch.substitutions import Command, FindExecutable, PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    pkg_path = get_package_share_directory('diff_robot')
    turtlebot3_gazebo_path = get_package_share_directory('turtlebot3_gazebo')
    nav2_bringup_path = get_package_share_directory('nav2_bringup')
    
    # Generate robot description
    robot_description = Command([
        FindExecutable(name='xacro'), ' ',
        PathJoinSubstitution([
            FindPackageShare('diff_robot'),
            'urdf',
            'diff_robot.urdf'
        ])
    ])

    # Robot State Publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description,
            'use_sim_time': True,
            'publish_frequency': 50.0
        }]
    )

    # Gazebo launch with TurtleBot3 world
    gazebo = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('gazebo_ros'),
                'launch',
                'gazebo.launch.py'
            ])
        ]),
        launch_arguments={
            'world': os.path.join(turtlebot3_gazebo_path, 'worlds', 'turtlebot3_world.world'),
            'verbose': 'true',
            'pause': 'false'
        }.items()
    )

    # Spawn Robot
    spawn_entity = Node(
        package='gazebo_ros',
        executable='spawn_entity.py',
        arguments=[
            '-topic', 'robot_description',
            '-entity', 'diff_robot',
            '-x', '0.5', '-y', '0.0', '-z', '0.1',
            '-Y', '0.0'
        ],
        output='screen'
    )

    # Static transform
    static_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        arguments=['0', '0', '0.1', '0', '0', '0', 'base_footprint', 'base_link'],
        output='screen'
    )

    # Map Server (load the map you created earlier)
    map_server = Node(
        package='nav2_map_server',
        executable='map_server',
        name='map_server',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'yaml_filename': os.path.expanduser('~/my_map.yaml')
        }],
        remappings=[
           ('/map', '/map'),
           ('/map_metadata', '/map_metadata')
        ]
    )

    # AMCL (Localization)
    amcl = Node(
        package='nav2_amcl',
        executable='amcl',
        name='amcl',
        output='screen',
        parameters=[os.path.join(pkg_path, 'config', 'amcl.yaml')]
    )

    # Navigation 2
    nav2_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            PathJoinSubstitution([
                FindPackageShare('nav2_bringup'),
                'launch',
                'navigation_launch.py'
            ])
        ]),
        launch_arguments={
            'use_sim_time': 'true',
            'params_file': os.path.join(pkg_path, 'config', 'nav2_params.yaml')
        }.items()
    )

    # Lifecycle Manager to activate nodes
    lifecycle_manager = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager',
        output='screen',
        parameters=[{
            'use_sim_time': True,
            'autostart': True,
            'node_names': ['map_server', 'amcl']
        }]
    )

    # RViz with navigation configuration
    rviz_config_file = os.path.join(pkg_path, 'config', 'turtlebot3_navigation.rviz')
    
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen',
        arguments=['-d', rviz_config_file],
        parameters=[{'use_sim_time': True}]
    )

    return LaunchDescription([
        # Start basic components
        robot_state_publisher,
        gazebo,
        spawn_entity,
        static_tf,
        
        # Start navigation components after Gazebo is ready
        RegisterEventHandler(
            event_handler=OnProcessExit(
                target_action=spawn_entity,
                on_exit=[map_server, amcl, nav2_launch, lifecycle_manager, rviz_node]
            )
        )
    ])
